# Case:Please write a program which accepts a string from console and print it in reverse order. 

# Example: If the following string is given as input to the program: 
# rise to vote sir 

# Then, the output of the program should be: 
# ris etov ot esir



str=input("Enter string which you want to reverse: ")

print("Reverse of the string is: ")
print(str[::-1])
