print("Hello World")
print("Welcome to Python")

print("Happy Learning \nWelcome to Python")